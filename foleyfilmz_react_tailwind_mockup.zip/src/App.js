import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import "./index.css";

const events = [
  { name: "Southern Classic Finals", date: "May 11, 2025", slug: "southern-classic" },
  { name: "2025 Spring Bash", date: "March 30, 2025", slug: "spring-bash" },
];

function Home() {
  return (
    <div className="min-h-screen bg-black text-blue-400">
      <h1 className="text-4xl font-bold text-center text-white py-8">FOLEYFILMZ</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-6 max-w-4xl mx-auto">
        {events.map((event) => (
          <div key={event.slug} className="bg-[#111] rounded-2xl shadow-xl p-6 text-center">
            <h2 className="text-2xl text-blue-400">{event.name}</h2>
            <p className="text-gray-400">{event.date}</p>
            <Link to={`/${event.slug}`}>
              <button className="mt-4 px-4 py-2 border-2 border-blue-400 rounded-lg hover:bg-blue-400 hover:text-black">
                Get Videos
              </button>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}

function EventPage({ title }) {
  return (
    <div className="min-h-screen bg-black text-blue-400 p-4">
      <h1 className="text-3xl text-center text-white mb-6">{title}</h1>
      {[...Array(10)].map((_, i) => (
        <div key={i} className="bg-[#111] rounded-lg shadow-md p-4 my-3 max-w-xl mx-auto flex justify-between items-center">
          <span className="text-white">🔒 Rider {i + 1}</span>
          <button className="px-3 py-1 border-2 border-blue-400 rounded-md hover:bg-blue-400 hover:text-black">
            Unlock – $80
          </button>
        </div>
      ))}
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/southern-classic" element={<EventPage title="Southern Classic Finals" />} />
        <Route path="/spring-bash" element={<EventPage title="2025 Spring Bash" />} />
      </Routes>
    </Router>
  );
}

export default App;
